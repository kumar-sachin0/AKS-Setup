# GitHub Actions + AWS EKS: Production-grade CI/CD Practice Project

एक छोटी **Orders API (Python Flask)** को GitHub Actions से
**test → Docker build → Trivy scan → ECR push → Helm से EKS पर deploy (dev automatic, prod approval के साथ)** करने का पूरा project।
GitHub में **कोई भी AWS access key store नहीं होती**, सब कुछ **OIDC** से होता है।

---

## 1. Project structure

```
gha-eks-project/
├── app/                          # Flask API + tests
│   ├── main.py
│   ├── requirements.txt          # runtime dependencies
│   ├── requirements-dev.txt      # pytest, flake8
│   └── tests/
├── Dockerfile                    # multi-stage, non-root user
├── helm/myapp/                   # Helm chart (deployment, service, hpa, pdb, networkpolicy)
│   ├── values-dev.yaml
│   └── values-prod.yaml
├── terraform/
│   ├── bootstrap/                # एक बार laptop से: S3 state bucket, GitHub OIDC, IAM roles
│   └── infra/                    # pipeline से: ECR, VPC, EKS, access entries, namespaces
└── .github/
    ├── actions/setup-tools/      # composite action (AWS login + Helm + kubectl)
    ├── workflows/
    │   ├── ci.yml                # PR checks: matrix tests, lint, docker build, helm lint, tf validate
    │   ├── build-deploy.yml      # main पर: build → scan → push → dev → prod
    │   ├── deploy.yml            # reusable workflow (workflow_call)
    │   ├── terraform.yml         # PR पर plan + comment, main पर apply (approval)
    │   └── terraform-destroy.yml # manual cleanup
    └── dependabot.yml
```

---

## 2. Pipeline कैसे काम करती है

| Event | Workflow | क्या होता है |
|---|---|---|
| Pull Request | `ci.yml` | सिर्फ बदले हुए हिस्से check होते हैं (paths-filter): Python 3.11/3.12 matrix tests, flake8, Docker build, Helm lint, Terraform validate |
| PR में `terraform/infra` बदला | `terraform.yml` | **read-only role** से `terraform plan`, output PR में comment |
| `main` पर merge (infra) | `terraform.yml` | `infra` environment approval के बाद `terraform apply` |
| `main` पर merge (app/helm) | `build-deploy.yml` | Image build → Trivy scan (HIGH/CRITICAL पर fail) → ECR push → **dev** deploy → approval → **prod** deploy |
| Manual | `terraform-destroy.yml` | "destroy" type करने और approval के बाद सब delete |

**IAM roles (हर काम के लिए अलग, least privilege):**

| Role | कौन use करता है (OIDC `sub` claim) | Permission |
|---|---|---|
| `gha-ecr-push-role` | `main` branch का build job | सिर्फ `myapp` ECR repo में push |
| `gha-terraform-plan-role` | Pull requests | ReadOnly + state file |
| `gha-terraform-apply-role` | `infra` environment | Admin (सिर्फ approval के बाद) |
| `gha-deploy-dev-role` | `dev` environment | EKS में सिर्फ `dev` namespace |
| `gha-deploy-prod-role` | `prod` environment | EKS में सिर्फ `prod` namespace |

यानी किसी PR से production में deploy या infra apply **संभव ही नहीं** है।

---

## 3. Prerequisites

- GitHub account और एक नया **empty repo** (जैसे `gha-eks-project`)
- AWS account, और laptop पर admin access के साथ AWS CLI login (`aws sso login` या `aws configure`)
- Laptop पर tools: `git`, `terraform` (>= 1.10), `aws` CLI, `kubectl`, `helm`, `docker` (optional)

> ⚠️ **Cost:** EKS cluster (~$0.10/घंटा), NAT Gateway (~$0.045/घंटा + data) और 2 × t3.medium nodes का charge लगता है।
> Practice खत्म होते ही **Step 10 (cleanup)** ज़रूर करें। Region के हिसाब से rate अलग हो सकते हैं।

---

## 4. Setup steps

### Step 1: Code को अपने repo में push करें

```bash
cd gha-eks-project
terraform fmt -recursive terraform/     # first commit से पहले formatting ठीक करें (CI इसे check करता है)
git init && git add . && git commit -m "Initial project"
git branch -M main
git remote add origin https://github.com/<YOUR_USER>/gha-eks-project.git
```

अभी **push मत करें**, पहले Step 2 और 3 पूरे करें, नहीं तो workflows बिना variables के fail होंगे।

### Step 2: Bootstrap (laptop से, सिर्फ एक बार)

ये S3 state bucket, GitHub OIDC provider और सारे IAM roles बनाता है।

```bash
cd terraform/bootstrap
terraform init
terraform apply -var="github_repo=<YOUR_USER>/gha-eks-project"
```

Apply के बाद outputs note करें:

```bash
terraform output
```

> Region बदलना हो तो `-var="region=us-east-1"` दें, और `terraform/infra` में भी वही region रखें।

### Step 3: GitHub settings

**(a) Repository variables:** Settings → Secrets and variables → Actions → **Variables** tab → New repository variable

| Name | Value |
|---|---|
| `AWS_REGION` | `ap-south-1` |
| `TF_STATE_BUCKET` | output `state_bucket` |
| `ECR_PUSH_ROLE_ARN` | output `ecr_push_role_arn` |
| `TF_PLAN_ROLE_ARN` | output `tf_plan_role_arn` |
| `TF_APPLY_ROLE_ARN` | output `tf_apply_role_arn` |
| `EKS_CLUSTER_NAME` | `gha-eks-cluster` |

ये सब **variables** हैं, secrets नहीं, क्योंकि role ARNs secret नहीं होते। असली सुरक्षा IAM trust policy में है।

**(b) Environments:** Settings → **Environments** → New environment

| Environment | Settings |
|---|---|
| `infra` | **Required reviewers:** खुद को add करें. **Deployment branches:** सिर्फ `main` |
| `dev` | Environment variable `DEPLOY_ROLE_ARN` = output `deploy_role_arns["dev"]` |
| `prod` | **Required reviewers:** खुद को add करें. **Deployment branches:** सिर्फ `main`. Variable `DEPLOY_ROLE_ARN` = output `deploy_role_arns["prod"]` |

**(c) Actions permissions:** Settings → Actions → General → "Workflow permissions" को **Read repository contents** रखें
(workflows खुद ज़रूरत के हिसाब से permissions माँगते हैं)।

### Step 4: Push करें और infra बनाएँ

```bash
git push -u origin main
```

- **Terraform** workflow चलेगा और `infra` approval माँगेगा → Actions tab में **Review deployments → Approve**।
- EKS बनने में लगभग **15–20 मिनट** लगते हैं।
- पहले push पर **Build and Deploy** workflow भी चलेगा और fail होगा, क्योंकि ECR और cluster अभी बने नहीं हैं। ये expected है।

### Step 5: पहला deployment

Infra बनने के बाद: Actions → **Build and Deploy** → **Run workflow** (main)।

- Build → Trivy scan → ECR push → **dev** deploy automatic
- **prod** के लिए approval माँगेगा → Approve

Laptop से check करें (अपने admin user को cluster access देना हो तो Step 8 देखें):

```bash
kubectl -n dev get pods
kubectl -n dev port-forward svc/myapp 8080:80
curl http://localhost:8080/orders
```

### Step 6: Branch protection

Settings → Branches → Add rule (या Rulesets) for `main`:
- **Require a pull request before merging** (approval के साथ)
- **Require status checks to pass:** CI के jobs select करें
- Direct push बंद

अब हर बदलाव PR से होगा।

### Step 7: पूरा flow test करें

```bash
git checkout -b feature/new-order
# app/main.py में ORDERS में एक नया order add करें और test update करें
git commit -am "Add new order"
git push -u origin feature/new-order
```

PR खोलें → CI checks देखें → merge → dev deploy → prod approve।

### Step 8 (optional): अपने laptop user को cluster access दें

Cluster creator सिर्फ pipeline का apply role है। अपने IAM user/role को access देने के लिए
`terraform/infra/main.tf` में `access_entries` के अंदर एक entry add करें
(जैसे `AmazonEKSClusterAdminPolicy` cluster scope के साथ) और PR से apply करें।
ये **access entries + RBAC** का अच्छा practice है।

---

## 5. Practice exercises (interview stories बनाने के लिए)

| # | क्या करें | क्या सीखेंगे |
|---|---|---|
| 1 | कोई test fail करवाकर PR बनाएँ | Required checks merge रोकते हैं |
| 2 | Dockerfile में पुराना base image डालें (जैसे `python:3.9-slim` का कोई पुराना tag) | Trivy pipeline रोकता है |
| 3 | `values-dev.yaml` में `service.targetPort: 9090` कर दें | Probes fail → `--atomic` automatic **rollback** |
| 4 | `helm rollback myapp <revision> -n prod` laptop से | Manual rollback |
| 5 | Console से EKS node group का size बदलें, फिर infra PR बनाएँ | Plan में **drift** दिखना |
| 6 | एक ही समय में दो commits merge करें | `concurrency` deploys को queue करता है |
| 7 | PR से `gha-deploy-prod-role` assume करने की कोशिश (workflow बदलकर) | OIDC `sub` condition से **AccessDenied** |
| 8 | Dependabot के PRs review करें | Actions और dependencies updates |

---

## 6. Senior-level improvements (next steps)

- **Actions को commit SHA से pin करें** (tags की जगह), खासकर third-party actions जैसे Trivy। Dependabot SHA pins को भी update करता है।
- **Fully private cluster:** `cluster_public_access_cidrs` को सिर्फ office/VPN CIDR पर करें, और deploy के लिए **Actions Runner Controller (ARC)** से VPC के अंदर self-hosted runners चलाएँ।
- **Terraform apply role** को `AdministratorAccess` की जगह सिर्फ VPC/EKS/ECR/IAM actions तक सीमित करें।
- **Image signing:** cosign से image sign करें, और Kyverno से सिर्फ signed images allow करें।
- **GitOps:** Helm deploy की जगह Argo CD, जिसमें pipeline सिर्फ image tag update करे।
- **Ingress:** AWS Load Balancer Controller + ALB + ACM certificate से app को HTTPS पर expose करें।
- **Notifications:** deploy fail होने पर Slack alert।

---

## 7. Troubleshooting

| Error | Reason | Fix |
|---|---|---|
| `Not authorized to perform sts:AssumeRoleWithWebIdentity` | OIDC `sub` match नहीं हुआ | `github_repo` value check करें (case-sensitive), environment name check करें |
| `Credentials could not be loaded` | Job में `id-token: write` नहीं | Workflow/job permissions check करें |
| Terraform `fmt -check` fail | Formatting | `terraform fmt -recursive terraform/` चलाकर commit करें |
| Helm: `namespaces "dev" is forbidden` | Deploy role का access entry नहीं बना | Infra apply पूरा हुआ? Environment का `DEPLOY_ROLE_ARN` सही है? |
| Pod `CreateContainerConfigError` / PSS error | Namespace `restricted` Pod Security लागू करता है | Chart का securityContext न हटाएँ |
| `ImagePullBackOff` | गलत image tag या repo | `kubectl describe pod`, ECR में tag check करें |
| Smoke test fail | App ready नहीं या port गलत | `kubectl -n dev logs deploy/myapp` |

---

## 8. Cleanup (बहुत ज़रूरी, नहीं तो charge लगता रहेगा)

1. Actions → **Terraform Destroy (manual)** → Run workflow → `destroy` type करें → `infra` approval दें।
   (ये EKS, VPC, NAT Gateway, ECR सब delete करता है। लगभग 10–15 मिनट।)
2. फिर laptop से bootstrap हटाएँ:

```bash
cd terraform/bootstrap
terraform destroy -var="github_repo=<YOUR_USER>/gha-eks-project"
```

3. AWS console में **EC2 → Load Balancers, EBS Volumes** और **VPC → NAT Gateways** check करें कि कुछ बचा न हो।

---

## 9. Interview में इसे कैसे बताएँ (2 मिनट version)

> "मैंने GitHub Actions पर एक end-to-end CI/CD pipeline बनाई। PR पर **paths-filter** से सिर्फ बदले हिस्से test होते हैं: Python matrix tests, Docker build, Helm lint और Terraform validate, और infra बदलने पर **read-only role** से plan चलकर PR में comment होता है।
> Merge होने पर image **Buildx cache** के साथ बनती है, **Trivy** scan करता है, और fixable HIGH/CRITICAL vulnerability पर pipeline रुक जाती है। Image commit SHA से tag होकर **immutable ECR** repo में जाती है।
> Authentication पूरी तरह **OIDC** से है, हर काम के लिए अलग IAM role, और trust policy में `sub` condition से तय है कि prod role सिर्फ `prod` environment से ही assume हो सकता है। Deploy एक **reusable workflow** और **composite action** से होता है, dev automatic और prod **approval** के बाद, और Helm `--atomic` fail होने पर automatic rollback करता है। EKS में deploy roles को **access entries** से सिर्फ अपने namespace का access है, और namespaces पर **restricted Pod Security** लागू है।"
