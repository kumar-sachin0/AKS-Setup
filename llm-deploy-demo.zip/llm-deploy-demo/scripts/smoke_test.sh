#!/usr/bin/env bash
# Quick end-to-end check: health, then two identical chats (2nd should be a
# cache hit with much lower latency).
set -euo pipefail

BASE="${BASE:-http://localhost:8000}"

echo ">> /health"
curl -s "${BASE}/health" | python3 -m json.tool

echo; echo ">> /chat (first call -> cache miss)"
curl -s -X POST "${BASE}/chat" \
  -H "Content-Type: application/json" \
  -d '{"message": "In one sentence, what is DevOps?"}' | python3 -m json.tool

echo; echo ">> /chat (identical call -> cache hit, note cache_hit=true + low latency_ms)"
curl -s -X POST "${BASE}/chat" \
  -H "Content-Type: application/json" \
  -d '{"message": "In one sentence, what is DevOps?"}' | python3 -m json.tool

echo; echo ">> First few metrics lines"
curl -s "${BASE}/metrics" | grep -E "llm_(requests|tokens)" | head -n 10
