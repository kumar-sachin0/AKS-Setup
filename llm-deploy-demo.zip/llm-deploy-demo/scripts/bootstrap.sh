#!/usr/bin/env bash
# One-shot: start the core stack and pull the local model.
set -euo pipefail

MODEL="${OLLAMA_MODEL:-qwen2.5:0.5b}"

echo ">> Starting core stack (api, litellm, redis, ollama)..."
docker compose up -d --build

echo ">> Waiting for Ollama to be ready..."
for i in $(seq 1 30); do
  if docker compose exec -T ollama ollama list >/dev/null 2>&1; then
    break
  fi
  sleep 2
done

echo ">> Pulling model: ${MODEL} (first run downloads it; ~400MB for qwen2.5:0.5b)"
docker compose exec -T ollama ollama pull "${MODEL}"

echo ">> Done. Try:  ./scripts/smoke_test.sh"
