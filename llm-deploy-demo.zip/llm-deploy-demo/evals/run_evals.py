#!/usr/bin/env python3
"""Run the offline eval set against the /chat API (or a mock).

Why this exists: you can't write `assert output == expected` for an LLM, so the
"test suite" is a set of property checks over an eval set, scored as a pass
rate against a threshold. This is the thing you wire into CI so a prompt or
model change can't silently regress quality.

Usage:
    python run_evals.py --url http://localhost:8000 --threshold 0.75
    python run_evals.py --mock          # no stack needed; used in CI
"""
import argparse
import sys
import urllib.error
import urllib.request
import json
from pathlib import Path

try:
    import yaml
except ImportError:
    print("Install deps first: pip install -r evals/requirements.txt", file=sys.stderr)
    raise


def load_cases(path: Path) -> list[dict]:
    with open(path) as f:
        return yaml.safe_load(f)["cases"]


def call_api(url: str, prompt: str, timeout: float) -> str:
    payload = json.dumps({"message": prompt}).encode()
    req = urllib.request.Request(
        f"{url.rstrip('/')}/chat",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read())["reply"]


def mock_reply(prompt: str) -> str:
    """Deterministic canned answers so CI can exercise the harness offline."""
    p = prompt.lower()
    if "capital of france" in p:
        return "Paris"
    if "7 multiplied by 6" in p:
        return "42"
    if "json object" in p:
        return '{"name": "Ada", "age": 36}'
    if "say hello" in p:
        return "Hello!"
    if "kubernetes" in p:
        return "Open-source container orchestration platform"
    if "good morning" in p:
        return "buenos días"
    if "primary colors" in p:
        return "red, blue, yellow"
    if "hello world" in p:
        return 'print("hello world")'
    return "ok"


def check(case: dict, output: str) -> bool:
    kind = case["check"]
    out = output.lower()
    if kind == "non_empty":
        return bool(output.strip())
    if kind == "max_words":
        return len(output.split()) <= int(case["limit"])
    if kind == "contains_any":
        return any(e.lower() in out for e in case["expect"])
    if kind == "contains_all":
        return all(e.lower() in out for e in case["expect"])
    raise ValueError(f"Unknown check type: {kind}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--url", default="http://localhost:8000")
    ap.add_argument("--mock", action="store_true", help="use canned replies, no API")
    ap.add_argument("--threshold", type=float, default=0.75)
    ap.add_argument("--timeout", type=float, default=90.0)
    args = ap.parse_args()

    cases = load_cases(Path(__file__).parent / "eval_set.yaml")
    passed = 0

    print(f"Running {len(cases)} eval cases "
          f"({'mock' if args.mock else args.url})\n")
    for c in cases:
        try:
            out = mock_reply(c["prompt"]) if args.mock else call_api(
                args.url, c["prompt"], args.timeout)
            ok = check(c, out)
        except (urllib.error.URLError, TimeoutError) as exc:
            print(f"  ERROR  {c['name']}: could not reach API ({exc})")
            ok = False
            out = ""
        passed += ok
        mark = "PASS" if ok else "FAIL"
        preview = out.replace("\n", " ")[:60]
        print(f"  [{mark}] {c['name']:<18} -> {preview}")

    rate = passed / len(cases)
    print(f"\nScore: {passed}/{len(cases)} = {rate:.0%} "
          f"(threshold {args.threshold:.0%})")
    if rate < args.threshold:
        print("RESULT: FAILED (below threshold)")
        return 1
    print("RESULT: PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
