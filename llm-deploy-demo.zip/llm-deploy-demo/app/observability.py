"""Observability: Prometheus metrics (always on) + optional Langfuse tracing.

Two complementary layers, which is a good interview talking point:

  * Prometheus/Grafana  -> operational metrics: request rate, latency, token
    counts, cache-hit rate. Zero account setup, scraped automatically.
  * Langfuse            -> deep per-request tracing of prompt/response/cost.
    Optional: only activates if LANGFUSE_* keys are in the environment.

The key idea for LLM ops: normal APM (CPU/memory) is not enough -- you also
need token, cost, and quality signals, which is why these exist.
"""
import logging

from prometheus_client import Counter, Histogram

log = logging.getLogger("observability")

# --- Prometheus metrics -----------------------------------------------------
REQUESTS = Counter(
    "llm_requests_total",
    "Total chat requests.",
    ["model", "cache_hit", "status"],
)
LATENCY = Histogram(
    "llm_request_latency_seconds",
    "End-to-end chat request latency.",
    ["model", "cache_hit"],
    buckets=(0.05, 0.1, 0.25, 0.5, 1, 2, 5, 10, 30),
)
TOKENS = Counter(
    "llm_tokens_total",
    "Tokens processed, by kind.",
    ["model", "kind"],  # kind = prompt | completion
)


# --- Optional Langfuse tracing ---------------------------------------------
class _NoopTrace:
    def update(self, *a, **k):
        pass

    def end(self, *a, **k):
        pass


class Tracer:
    """Thin wrapper so the app code is identical whether or not Langfuse runs."""

    def __init__(self, settings):
        self.client = None
        if not settings.langfuse_enabled:
            log.info("Langfuse disabled (no keys). Prometheus metrics still on.")
            return
        try:
            from langfuse import Langfuse

            self.client = Langfuse(
                public_key=settings.LANGFUSE_PUBLIC_KEY,
                secret_key=settings.LANGFUSE_SECRET_KEY,
                host=settings.LANGFUSE_HOST or None,
            )
            log.info("Langfuse tracing enabled.")
        except Exception as exc:  # pragma: no cover - optional dependency/infra
            log.warning("Langfuse init failed, continuing without it: %s", exc)
            self.client = None

    def trace(self, name: str, user_input: str):
        if not self.client:
            return _NoopTrace()
        try:
            return self.client.trace(name=name, input=user_input)
        except Exception as exc:  # pragma: no cover
            log.warning("Langfuse trace failed: %s", exc)
            return _NoopTrace()
