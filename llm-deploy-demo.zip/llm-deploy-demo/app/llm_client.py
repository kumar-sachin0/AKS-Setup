"""Client for the LiteLLM gateway.

The app speaks the OpenAI chat-completions protocol to the *gateway*, never to
a provider directly. That indirection is the whole point of an LLM gateway:
one place for multi-provider routing, fallbacks, retries, and cost tracking.
Swap the model or provider in litellm/config.yaml without touching app code.
"""
import logging

from openai import OpenAI

from config import settings

log = logging.getLogger("llm_client")


class LLMClient:
    def __init__(self):
        self.client = OpenAI(
            base_url=settings.LLM_BASE_URL,
            api_key=settings.LLM_API_KEY,  # from env (Rule A)
            timeout=settings.REQUEST_TIMEOUT_S,
            max_retries=2,  # simple retry/backoff for transient failures
        )

    def complete(self, message: str, model: str) -> tuple[str, dict]:
        """Return (reply_text, token_usage)."""
        resp = self.client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": message}],
        )
        reply = resp.choices[0].message.content or ""
        usage = resp.usage
        tokens = {
            "prompt_tokens": getattr(usage, "prompt_tokens", 0) or 0,
            "completion_tokens": getattr(usage, "completion_tokens", 0) or 0,
            "total_tokens": getattr(usage, "total_tokens", 0) or 0,
        }
        return reply, tokens


llm = LLMClient()
