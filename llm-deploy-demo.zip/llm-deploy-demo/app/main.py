"""FastAPI service: the thin, stateless layer in front of the LLM stack.

Request flow:
    client -> /chat -> cache check -> LiteLLM gateway -> model
                         |                                  |
                     (hit: return)                 record tokens/latency,
                                                   cache the answer, trace

Operational features worth pointing at in an interview:
  * caching (cost control)
  * a gateway seam (routing / fallback / provider-swap)
  * Prometheus metrics at /metrics (token + cost signals, not just CPU)
  * optional Langfuse tracing
  * /health for liveness/readiness probes
  * generic error responses (no internal details leaked to the caller)
"""
import logging
import time

from fastapi import FastAPI, HTTPException
from fastapi.responses import Response
from prometheus_client import CONTENT_TYPE_LATEST, generate_latest

from cache import cache
from config import settings
from llm_client import llm
from observability import LATENCY, REQUESTS, TOKENS, Tracer
from schemas import ChatRequest, ChatResponse, HealthResponse

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("api")

app = FastAPI(title="LLM Deployment Demo", version="1.0.0")
tracer = Tracer(settings)


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(
        status="ok",
        model=settings.DEFAULT_MODEL,
        cache="up" if cache.enabled else "disabled",
        observability="langfuse+prometheus" if settings.langfuse_enabled else "prometheus",
    )


@app.get("/metrics")
def metrics() -> Response:
    # Scraped by Prometheus; exposes llm_requests_total, latency, tokens.
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest) -> ChatResponse:
    model = req.model or settings.DEFAULT_MODEL
    started = time.perf_counter()
    span = tracer.trace("chat", req.message)

    # 1) Cache: identical (model, message) is served for free.
    cached = cache.get(model, req.message)
    if cached is not None:
        latency = time.perf_counter() - started
        REQUESTS.labels(model, "true", "ok").inc()
        LATENCY.labels(model, "true").observe(latency)
        span.update(output=cached, metadata={"cache_hit": True})
        return ChatResponse(
            reply=cached, model=model, cache_hit=True,
            prompt_tokens=0, completion_tokens=0, total_tokens=0,
            latency_ms=round(latency * 1000, 1),
        )

    # 2) Miss: call the gateway.
    try:
        reply, tokens = llm.complete(req.message, model)
    except Exception as exc:
        # Log detail server-side; return a generic message to the caller
        # (adobe-security-foundations, secure error handling).
        REQUESTS.labels(model, "false", "error").inc()
        log.exception("LLM call failed: %s", exc)
        span.update(metadata={"error": True})
        raise HTTPException(status_code=502, detail="Upstream model request failed.")

    latency = time.perf_counter() - started
    cache.set(model, req.message, reply)

    REQUESTS.labels(model, "false", "ok").inc()
    LATENCY.labels(model, "false").observe(latency)
    TOKENS.labels(model, "prompt").inc(tokens["prompt_tokens"])
    TOKENS.labels(model, "completion").inc(tokens["completion_tokens"])
    span.update(output=reply, metadata={"cache_hit": False, **tokens})

    return ChatResponse(
        reply=reply, model=model, cache_hit=False,
        prompt_tokens=tokens["prompt_tokens"],
        completion_tokens=tokens["completion_tokens"],
        total_tokens=tokens["total_tokens"],
        latency_ms=round(latency * 1000, 1),
    )
