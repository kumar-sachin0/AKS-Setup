"""Central config, all from environment variables.

Rule A (adobe-security-foundations): no hardcoded credentials. Every secret is
read from the environment; nothing sensitive is committed. See .env.example.
"""
import os


class Settings:
    # --- LLM gateway (LiteLLM proxy, OpenAI-compatible) ---
    # The app never talks to a provider directly; it goes through the gateway.
    LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "http://litellm:4000/v1")
    # LiteLLM requires *some* key on the OpenAI-compatible route. For the local
    # Ollama demo any non-empty string works; a real key lives only in env.
    LLM_API_KEY: str = os.getenv("LLM_API_KEY", "sk-local-demo-not-a-secret")
    DEFAULT_MODEL: str = os.getenv("DEFAULT_MODEL", "local-llm")
    REQUEST_TIMEOUT_S: float = float(os.getenv("REQUEST_TIMEOUT_S", "60"))

    # --- Cache ---
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://redis:6379/0")
    CACHE_TTL_S: int = int(os.getenv("CACHE_TTL_S", "3600"))

    # --- Observability (Langfuse is optional; off unless keys are present) ---
    LANGFUSE_PUBLIC_KEY: str = os.getenv("LANGFUSE_PUBLIC_KEY", "")
    LANGFUSE_SECRET_KEY: str = os.getenv("LANGFUSE_SECRET_KEY", "")
    LANGFUSE_HOST: str = os.getenv("LANGFUSE_HOST", "")

    @property
    def langfuse_enabled(self) -> bool:
        return bool(self.LANGFUSE_PUBLIC_KEY and self.LANGFUSE_SECRET_KEY)


settings = Settings()
