"""Exact-match response cache backed by Redis.

Caching is a core LLM-ops cost lever: identical prompts should not be paid for
twice. This is *exact-match* (hash of model+message). Semantic caching (embed
the prompt, reuse answers for similar prompts) is the production upgrade and is
noted in the README as a next step.

Degrades gracefully: if Redis is down, the app still answers, just without
caching. Fail-open is acceptable here because the cache is a performance
optimization, not a security control.
"""
import hashlib
import logging

import redis

from config import settings

log = logging.getLogger("cache")


class ResponseCache:
    def __init__(self, url: str, ttl: int):
        self.ttl = ttl
        self.enabled = False
        try:
            self.client = redis.Redis.from_url(url, socket_connect_timeout=2)
            self.client.ping()
            self.enabled = True
        except Exception as exc:  # pragma: no cover - infra dependent
            log.warning("Cache disabled (Redis unavailable): %s", exc)
            self.client = None

    @staticmethod
    def _key(model: str, message: str) -> str:
        # SHA-256 (Rule B: approved hash). Used only as a cache key, not for
        # any security purpose.
        digest = hashlib.sha256(f"{model}::{message}".encode()).hexdigest()
        return f"chat:{digest}"

    def get(self, model: str, message: str) -> str | None:
        if not self.enabled:
            return None
        try:
            val = self.client.get(self._key(model, message))
            return val.decode() if val else None
        except Exception as exc:  # pragma: no cover
            log.warning("Cache get failed: %s", exc)
            return None

    def set(self, model: str, message: str, reply: str) -> None:
        if not self.enabled:
            return
        try:
            self.client.setex(self._key(model, message), self.ttl, reply)
        except Exception as exc:  # pragma: no cover
            log.warning("Cache set failed: %s", exc)


cache = ResponseCache(settings.REDIS_URL, settings.CACHE_TTL_S)
