"""Request/response models.

Input validation here is a security control (see adobe-security-foundations:
validate type, length, range on every entry point). The max_length cap on the
prompt is a cheap defense against abuse / runaway token cost.
"""
from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    message: str = Field(
        ...,
        min_length=1,
        max_length=4000,  # cap input size -> bounds token cost and abuse
        description="The user prompt to send to the model.",
    )
    # Optional override so you can demo routing to a different model name
    # defined in the LiteLLM gateway config.
    model: str | None = Field(default=None, max_length=100)


class ChatResponse(BaseModel):
    reply: str
    model: str
    cache_hit: bool
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    latency_ms: float


class HealthResponse(BaseModel):
    status: str
    model: str
    cache: str
    observability: str
