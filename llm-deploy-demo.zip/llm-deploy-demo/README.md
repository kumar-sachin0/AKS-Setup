# LLM Deployment Demo (DevOps / LLM-Ops)

A small but realistic **LLM-backed API with production-style operations around
it**: a containerized service behind an **LLM gateway**, with **caching**,
**metrics/dashboards**, an **eval suite in CI**, and an optional **tracing**
layer. Built to learn — and to talk through — how deploying an LLM system
differs from shipping a normal web app.

Runs fully local with **no API keys and no paid services** (model served by
Ollama). Bring it up with one script.

---

## Architecture

```
          ┌───────────┐   POST /chat    ┌──────────────┐
  client ─▶   FastAPI  ├────────────────▶  LiteLLM      ├────▶  Ollama
          │   (api)   │                 │  gateway      │      (local model)
          └─────┬─────┘                 └──────────────┘
                │  ▲   routing · retries · fallback · cost
     cache get/ │  │
          set   ▼  │ metrics (/metrics)              optional
          ┌─────────┐        ┌────────────┐          ┌───────────┐
          │  Redis  │        │ Prometheus │──▶ Grafana│  Langfuse │ (deep
          └─────────┘        └────────────┘          └───────────┘  tracing)
```

Why each piece earns its place:

| Component | What it does | Why it matters for LLM ops |
|-----------|--------------|----------------------------|
| **FastAPI** `app/` | thin, stateless `/chat`, `/health`, `/metrics` | keep app stateless so it scales horizontally; heavy state lives in model/cache |
| **LiteLLM** gateway | one OpenAI-compatible seam in front of any provider | swap models, add **provider fallback**, central **cost tracking** without touching app code |
| **Redis** cache | serve identical prompts for free | **cost control** — the #1 reason DevOps gets pulled into LLM work |
| **Prometheus + Grafana** | request rate, p95 latency, **token** throughput, cache-hit ratio | normal APM (CPU/mem) isn't enough — you need **token/cost** signals |
| **Langfuse** (optional) | per-request prompt/response/cost trace | deep debugging of *why* a response was bad/expensive |
| **Eval suite + CI** | property checks over an eval set, scored vs a threshold | you **can't unit-test an LLM deterministically**, so quality gets a CI gate |

---

## Quick start (≈5 min, first run downloads a ~400MB model)

Prereq: Docker + Docker Compose.

```bash
cp .env.example .env          # defaults are fine for local
chmod +x scripts/*.sh
./scripts/bootstrap.sh        # starts core stack + pulls the model
./scripts/smoke_test.sh       # health + two chats (watch the 2nd hit the cache)
```

Then:

```bash
# Chat
curl -s -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"message":"Explain blue-green deployment in two sentences."}' | python3 -m json.tool

# Metrics Prometheus scrapes
curl -s http://localhost:8000/metrics | grep llm_
```

### Add dashboards (optional)

```bash
docker compose --profile observability up -d
# Grafana: http://localhost:3000  (admin/admin) -> dashboard "LLM Ops"
# Prometheus: http://localhost:9090
```

### Add deep tracing (optional)

Easiest is Langfuse Cloud free tier: create a project, put the keys in `.env`
(`LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY`, `LANGFUSE_HOST`), then
`docker compose up -d`. Or self-host: `docker compose --profile langfuse up -d`.

---

## Run the evals

```bash
pip install -r evals/requirements.txt
python evals/run_evals.py --url http://localhost:8000   # against live API
python evals/run_evals.py --mock                        # offline, like CI does
```

CI (`.github/workflows/ci.yml`) lints, import-checks the app, builds the image,
and runs the evals in mock mode on every push/PR.

---

## The two deployment paths (know both for the interview)

This project takes **Path A**. Be ready to contrast with **Path B**.

**Path A — consume a hosted/served model (what this repo does).**
No GPUs to manage. The work is *orchestration*: gateway, secrets, retries,
fallbacks, caching, cost control, observability, prompt/version management.
This is what most companies actually run.

**Path B — self-host open weights (Llama, Mistral, …).**
Now it's *infrastructure*: an inference server (**vLLM** or **TGI**) in a
CUDA container, **GPU node pools** on Kubernetes, weights pulled from **object
storage** at startup (never baked into the image), **quantization** to fit
hardware, and autoscaling. The hard parts:
- **Cold starts** — loading GB of weights onto a GPU takes minutes, so naive
  scale-to-zero hurts; you keep **warm capacity**.
- **GPU autoscaling** — GPUs are scarce/expensive; you scale on queue depth and
  batch requests (continuous batching) rather than spinning up instantly.

---

## Things to be aware of (interview follow-ups)

- **Cost** — token budgets, caching (exact-match here; **semantic caching** is
  the upgrade), right-sizing the model, cost per feature.
- **Observability** — trace prompt, response, tokens, latency, **cost per
  request**; standard metrics plus LLM-specific ones.
- **Evaluation** — offline eval sets in CI, regression checks on prompt/model
  changes, online A/B tests.
- **Reliability** — timeouts, retries w/ backoff, **provider fallback**,
  response **streaming** (time-to-first-token) for perceived latency.
- **Security** — secrets in a manager not in git, **prompt-injection** &
  output guardrails, scrub **PII** before logs/third parties.
- **Versioning** — model version + **prompt version** + config are deployable
  artifacts; roll out prompts gradually like code.

---

## Security notes (what was applied here)

- No hardcoded secrets — all via env; real `.env` is gitignored; `.env.example`
  holds placeholders only.
- Input validation — prompt is length-capped (bounds abuse and token cost).
- Secure errors — upstream failures return a generic 502; details are logged
  server-side, and keys/PII are never logged.
- Least privilege — API container runs as a non-root user.

These are demo-grade. For production you'd add real guardrails, auth on the
API, a managed secrets store, and PII redaction before third-party calls.

---

## Layout

```
app/            FastAPI service (main, llm_client, cache, observability, schemas)
litellm/        gateway config (model routing + fallback)
evals/          eval set + runner (live or --mock)
observability/  prometheus scrape + grafana datasource/dashboard
scripts/        bootstrap + smoke test
.github/        CI pipeline
docker-compose.yml   core + observability + langfuse profiles
```
